import React from 'react'

import Script from 'dangerous-html/react'

import './navigation.css'

const Navigation = (props) => {
  return (
    <div className="navigation-container1">
      <div className="navigation-container2">
        <div className="navigation-container3">
          <Script
            html={`<style>
@media (prefers-reduced-motion: reduce) {
.navigation, .navigation-link, .navigation-link::after, .navigation-toggle, .navigation-close, .navigation-mobile-link, .navigation-mobile-overlay {
  transition: none;
  animation: none;
}
.navigation-mobile-link, .navigation-mobile-cta {
  opacity: 1;
  transform: none;
}
}
</style>`}
          ></Script>
        </div>
      </div>
      <nav className="navigation">
        <div className="navigation-container">
          <a href="#">
            <div aria-label="Annonces pro homepage" className="navigation-logo">
              <span className="section-title">
                <span>{/*locale-SectionTitle_dc_UBF*/}</span>
              </span>
            </div>
          </a>
          <div className="navigation-desktop">
            <a href="#">
              <div className="navigation-link">
                <span>
                  <span>{/*locale-text_7zAEnv*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>
                  <span>{/*locale-text_ptRzC5*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>
                  <span>{/*locale-text_SghYoR*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-link">
                <span>
                  <span>{/*locale-text_1_OdbT*/}</span>
                </span>
              </div>
            </a>
            <button className="btn-primary navigation-cta btn">
              <svg
                width="20"
                xmlns="http://www.w3.org/2000/svg"
                height="20"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M5 12h14m-7-7v14"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <span>
                <span>{/*locale-text_e9fne6*/}</span>
              </span>
            </button>
          </div>
          <button
            aria-label="Toggle mobile menu"
            aria-expanded="false"
            className="navigation-toggle"
          >
            <svg
              width="28"
              xmlns="http://www.w3.org/2000/svg"
              height="28"
              viewBox="0 0 24 24"
              aria-hidden="true"
            >
              <path
                d="M4 5h16M4 12h16M4 19h16"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
            </svg>
          </button>
        </div>
        <div className="navigation-mobile-overlay">
          <div className="navigation-mobile-header">
            <a href="#">
              <div
                aria-label="Annonces pro homepage"
                className="navigation-mobile-logo"
              >
                <span className="section-title">
                  <span>{/*locale-SectionTitle_b9JZrK*/}</span>
                </span>
              </div>
            </a>
            <button aria-label="Close mobile menu" className="navigation-close">
              <svg
                width="32"
                xmlns="http://www.w3.org/2000/svg"
                height="32"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M18 6L6 18M6 6l12 12"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
            </button>
          </div>
          <div className="navigation-mobile-content">
            <a href="#">
              <div className="navigation-mobile-link">
                <span>
                  <span>{/*locale-text_8Ptt8X*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>
                  <span>{/*locale-text_OWIvYH*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>
                  <span>{/*locale-text_3uc9qC*/}</span>
                </span>
              </div>
            </a>
            <a href="#">
              <div className="navigation-mobile-link">
                <span>
                  <span>{/*locale-text_AoGxeJ*/}</span>
                </span>
              </div>
            </a>
            <button className="navigation-mobile-cta btn-primary btn-lg btn">
              <svg
                width="24"
                xmlns="http://www.w3.org/2000/svg"
                height="24"
                viewBox="0 0 24 24"
                aria-hidden="true"
              >
                <path
                  d="M5 12h14m-7-7v14"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                ></path>
              </svg>
              <span>
                <span>{/*locale-text_gDG7EZ*/}</span>
              </span>
            </button>
          </div>
        </div>
      </nav>
      <div className="navigation-container4">
        <div className="navigation-container5">
          <Script
            html={`<style>
        @keyframes slideInStagger {to {opacity: 1;
transform: translateX(0);}}@keyframes slideUpFade {to {opacity: 1;
transform: translateY(0);}}
        </style> `}
          ></Script>
        </div>
      </div>
      <div className="navigation-container6">
        <div className="navigation-container7">
          <Script
            html={`<script defer data-name="navigation-mobile-menu">
(function(){
  const navigationToggle = document.querySelector(".navigation-toggle")
  const navigationClose = document.querySelector(".navigation-close")
  const navigationMobileOverlay = document.querySelector(".navigation-mobile-overlay")
  const body = document.body

  function openMobileMenu() {
    navigationMobileOverlay.classList.add("is-open")
    navigationToggle.setAttribute("aria-expanded", "true")
    body.style.overflow = "hidden"
  }

  function closeMobileMenu() {
    navigationMobileOverlay.classList.remove("is-open")
    navigationToggle.setAttribute("aria-expanded", "false")
    body.style.overflow = ""
  }

  navigationToggle.addEventListener("click", openMobileMenu)
  navigationClose.addEventListener("click", closeMobileMenu)

  navigationMobileOverlay.addEventListener("click", (e) => {
    if (e.target === navigationMobileOverlay) {
      closeMobileMenu()
    }
  })

  const mobileLinks = document.querySelectorAll(".navigation-mobile-link, .navigation-mobile-cta")
  mobileLinks.forEach((link) => {
    link.addEventListener("click", closeMobileMenu)
  })

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && navigationMobileOverlay.classList.contains("is-open")) {
      closeMobileMenu()
    }
  })
})()
</script>`}
          ></Script>
        </div>
      </div>
    </div>
  )
}

export default Navigation
