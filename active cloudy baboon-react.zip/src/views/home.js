import React from 'react'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Navigation from '../components/navigation'
import Footer from '../components/footer'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Active Cloudy Baboon</title>
        <meta property="og:title" content="Active Cloudy Baboon" />
        <link
          rel="canonical"
          href="https://active-cloudy-baboon-l5qprk.teleporthq.app/"
        />
      </Helmet>
      <Navigation locale={props?.locale ?? ''}></Navigation>
      <div className="home-container2">
        <div className="home-container3">
          <Script
            html={`<style>
@media (prefers-reduced-motion: reduce) {
* {
  animation-duration: 0.01ms !important;
  animation-iteration-count: 1 !important;
  transition-duration: 0.01ms !important;
}
}
</style>`}
          ></Script>
        </div>
      </div>
      <section className="hero-carousel">
        <div className="hero-carousel-wrapper">
          <video
            src="https://videos.pexels.com/video-files/35201238/14913343_640_360_24fps.mp4"
            loop="true"
            muted="true"
            poster="https://images.pexels.com/videos/35201238/pictures/preview-0.jpg"
            autoPlay="true"
            playsInline="true"
            className="hero-carousel-video"
          ></video>
          <div className="hero-carousel-overlay"></div>
          <div className="hero-carousel-content">
            <div className="hero-carousel-slides">
              <div className="hero-carousel-slide active">
                <h1 className="hero-title">
                  <span>{/*locale-HeroTitle_nw8mEs*/}</span>
                </h1>
                <p className="hero-subtitle">
                  <span>{/*locale-HeroSubtitle_rlAXWz*/}</span>
                </p>
                <div className="hero-carousel-search">
                  <div className="hero-carousel-input-wrapper">
                    <svg
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="m21 21l-4.34-4.34"></path>
                        <circle r="8" cx="11" cy="11"></circle>
                      </g>
                    </svg>
                    <input
                      type="search"
                      placeholder="Search for anything..."
                      className="hero-carousel-input"
                    />
                  </div>
                  <button className="btn-primary hero-carousel-btn btn">
                    <span>{/*locale-Btn_9bjt2n*/}</span>
                  </button>
                </div>
                <button className="btn-secondary hero-carousel-submit btn">
                  <span>{/*locale-Btn_ntqWYK*/}</span>
                </button>
              </div>
              <div className="hero-carousel-slide">
                <h1 className="hero-title">
                  <span>{/*locale-HeroTitle_eh8nvu*/}</span>
                </h1>
                <p className="hero-subtitle">
                  <span>{/*locale-HeroSubtitle_0itOrr*/}</span>
                </p>
                <div className="hero-carousel-search">
                  <div className="hero-carousel-input-wrapper">
                    <svg
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="m21 21l-4.34-4.34"></path>
                        <circle r="8" cx="11" cy="11"></circle>
                      </g>
                    </svg>
                    <input
                      type="search"
                      placeholder="Search by category or location..."
                      className="hero-carousel-input"
                    />
                  </div>
                  <button className="btn-primary hero-carousel-btn btn">
                    <span>{/*locale-Btn_EZMTz0*/}</span>
                  </button>
                </div>
                <button className="btn-secondary hero-carousel-submit btn">
                  <span>{/*locale-Btn_5Qhlch*/}</span>
                </button>
              </div>
              <div className="hero-carousel-slide">
                <h1 className="hero-title">
                  <span>{/*locale-HeroTitle_WRj6_s*/}</span>
                </h1>
                <p className="hero-subtitle">
                  <span>{/*locale-HeroSubtitle_yAkhYw*/}</span>
                </p>
                <div className="hero-carousel-search">
                  <div className="hero-carousel-input-wrapper">
                    <svg
                      width="24"
                      xmlns="http://www.w3.org/2000/svg"
                      height="24"
                      viewBox="0 0 24 24"
                    >
                      <g
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                      >
                        <path d="m21 21l-4.34-4.34"></path>
                        <circle r="8" cx="11" cy="11"></circle>
                      </g>
                    </svg>
                    <input
                      type="search"
                      placeholder="What are you looking for?"
                      className="hero-carousel-input"
                    />
                  </div>
                  <button className="btn-primary hero-carousel-btn btn">
                    <span>{/*locale-Btn_XVevqZ*/}</span>
                  </button>
                </div>
                <button className="btn-secondary hero-carousel-submit btn">
                  <span>{/*locale-Btn_w0gzZT*/}</span>
                </button>
              </div>
            </div>
            <div className="hero-carousel-nav">
              <button
                aria-label="Previous slide"
                className="hero-carousel-prev"
              >
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="m15 18l-6-6l6-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
              <div className="hero-carousel-dots">
                <button
                  aria-label="Go to slide 1"
                  className="hero-carousel-dot active"
                ></button>
                <button
                  aria-label="Go to slide 2"
                  className="hero-carousel-dot"
                ></button>
                <button
                  aria-label="Go to slide 3"
                  className="hero-carousel-dot"
                ></button>
              </div>
              <button aria-label="Next slide" className="hero-carousel-next">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="m9 18l6-6l-6-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="search-filters">
        <div className="search-filters-wrapper">
          <div className="search-filters-header">
            <h2 className="section-title">
              <span>{/*locale-SectionTitle_IpD4lM*/}</span>
            </h2>
            <p className="section-subtitle">
              <span>{/*locale-SectionSubtitle_GPOZyH*/}</span>
            </p>
          </div>
          <div className="search-filters-container">
            <div className="search-filters-item">
              <div className="search-filters-icon">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"></path>
                    <circle
                      r=".5"
                      cx="7.5"
                      cy="7.5"
                      fill="currentColor"
                    ></circle>
                  </g>
                </svg>
              </div>
              <div className="search-filters-content">
                <label htmlFor="category" className="search-filters-label">
                  <span>{/*locale-SearchFiltersLabel_BEWYcv*/}</span>
                </label>
                <select id="category" className="search-filters-select">
                  <option value="true">All Categories</option>
                  <option value="real-estate">Real Estate</option>
                  <option value="vehicles">Vehicles</option>
                  <option value="jobs">Jobs</option>
                  <option value="services">Services</option>
                  <option value="electronics">Electronics</option>
                  <option value="furniture">Furniture</option>
                  <option value="fashion">Fashion</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
            <div className="search-filters-item">
              <div className="search-filters-icon">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M17.97 9.304A8 8 0 0 0 2 10c0 4.69 4.887 9.562 7.022 11.468m12.356-4.842a1 1 0 0 0-3.004-3.004l-4.01 4.012a2 2 0 0 0-.506.854l-.837 2.87a.5.5 0 0 0 .62.62l2.87-.837a2 2 0 0 0 .854-.506z"></path>
                    <circle r="3" cx="10" cy="10"></circle>
                  </g>
                </svg>
              </div>
              <div className="search-filters-content">
                <label htmlFor="location" className="search-filters-label">
                  <span>{/*locale-SearchFiltersLabel_tS6xYi*/}</span>
                </label>
                <input
                  type="text"
                  id="location"
                  placeholder="Enter city or region"
                  className="search-filters-input"
                />
              </div>
            </div>
            <div className="search-filters-item">
              <div className="search-filters-icon">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M2 5h20M6 12h12m-9 7h6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <div className="search-filters-content">
                <label htmlFor="price-range" className="search-filters-label">
                  <span>{/*locale-SearchFiltersLabel_TtBN_a*/}</span>
                </label>
                <div className="search-filters-price">
                  <input
                    type="number"
                    placeholder="Min"
                    className="search-filters-price-input"
                  />
                  <span className="search-filters-separator">
                    <span>{/*locale-SearchFiltersSeparator_KYdcvE*/}</span>
                  </span>
                  <input
                    type="number"
                    placeholder="Max"
                    className="search-filters-price-input"
                  />
                </div>
              </div>
            </div>
            <div className="search-filters-item">
              <div className="search-filters-icon">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M2 5h20M6 12h12m-9 7h6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <div className="search-filters-content">
                <label htmlFor="sort" className="search-filters-label">
                  <span>{/*locale-SearchFiltersLabel_T9CELl*/}</span>
                </label>
                <select id="sort" className="search-filters-select">
                  <option value="recent">Most Recent</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="popular">Most Popular</option>
                </select>
              </div>
            </div>
          </div>
          <div className="search-filters-actions">
            <button className="btn-primary btn">
              <span>{/*locale-Btn_BwT4E6*/}</span>
            </button>
            <button className="btn btn-outline">
              <span>{/*locale-Btn_1kZFS0*/}</span>
            </button>
          </div>
        </div>
      </section>
      <section className="product-listings">
        <div className="product-listings-container">
          <div className="product-listings-header">
            <h2 className="section-title">
              <span>{/*locale-SectionTitle_bohIzP*/}</span>
            </h2>
            <p className="section-subtitle">
              <span>{/*locale-SectionSubtitle_l8lCm9*/}</span>
            </p>
          </div>
          <div className="product-listings-grid">
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="An intimate Sankt-Peterburg interior with plants, window, and decor, capturing tranquil indoor daylight."
                  src="https://images.pexels.com/photos/2929360/pexels-photo-2929360.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
                <span className="product-listings-badge">
                  <span>{/*locale-ProductListingsBadge_ydH_M0*/}</span>
                </span>
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_SLMWxu*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_XBjtHs*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_sE-2Jj*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_Zjdi0P*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_hT7Loj*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_uXdkaw*/}</span>
                  </button>
                </div>
              </div>
            </article>
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="Modern minimalist dining room featuring wooden furniture, soft lighting, and contemporary art."
                  src="https://images.pexels.com/photos/709767/pexels-photo-709767.png?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_hIVINs*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_dddLuS*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_Q2_n0z*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_qb_1fV*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_w1UJyU*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_2XCdlT*/}</span>
                  </button>
                </div>
              </div>
            </article>
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="A modern beige sofa with wooden legs, perfect for stylish living room decor."
                  src="https://images.pexels.com/photos/11112731/pexels-photo-11112731.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
                <span className="product-listings-badge">
                  <span>{/*locale-ProductListingsBadge_HQrjPc*/}</span>
                </span>
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_8ZpmKw*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_aqMwYS*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_daT4tK*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_V3Tkoj*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_4Kv6XB*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_1zasOB*/}</span>
                  </button>
                </div>
              </div>
            </article>
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="Elegant modern bedroom design in London, featuring beige aesthetics and cozy lighting."
                  src="https://images.pexels.com/photos/21345931/pexels-photo-21345931.png?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_ZruJhI*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_SsSqIS*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_nbY-Dr*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_b8Re21*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_IcR0a5*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_jonDvN*/}</span>
                  </button>
                </div>
              </div>
            </article>
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="Elegant beige bedroom with modern decor and warm lighting, creating a cozy atmosphere."
                  src="https://images.pexels.com/photos/24380941/pexels-photo-24380941.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_-pUnLG*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_JY2sPw*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_9Q30yM*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_D9rpGN*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_OkIs45*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_MVf47E*/}</span>
                  </button>
                </div>
              </div>
            </article>
            <article className="product-listings-card">
              <div className="product-listings-image-wrapper">
                <img
                  alt="Elegant modern living room interior with a blue accent wall, television, and stylish lighting."
                  src="https://images.pexels.com/photos/28104067/pexels-photo-28104067.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                  className="product-listings-image"
                />
                <span className="product-listings-badge">
                  <span>{/*locale-ProductListingsBadge_WNq6L2*/}</span>
                </span>
              </div>
              <div className="product-listings-content">
                <h3 className="product-listings-title">
                  <span>{/*locale-ProductListingsTitle_jOeJpk*/}</span>
                </h3>
                <p className="product-listings-description">
                  <span>{/*locale-ProductListingsDescription_uNPM9v*/}</span>
                </p>
                <div className="product-listings-meta">
                  <span className="product-listings-price">
                    <span>{/*locale-ProductListingsPrice_9orv3q*/}</span>
                  </span>
                  <span className="product-listings-location">
                    <span>{/*locale-ProductListingsLocation_qJpS1x*/}</span>
                  </span>
                </div>
                <div className="product-listings-footer">
                  <span className="product-listings-time">
                    <span>{/*locale-ProductListingsTime_PvdOKg*/}</span>
                  </span>
                  <button className="product-listings-link btn-link btn">
                    <span>{/*locale-Btn_MWeCTo*/}</span>
                  </button>
                </div>
              </div>
            </article>
          </div>
          <div className="product-listings-more">
            <button className="btn-primary btn-lg btn">
              <span>{/*locale-Btn_y_BgAO*/}</span>
            </button>
          </div>
        </div>
      </section>
      <section className="features-benefits">
        <div className="features-benefits-wrapper">
          <div className="features-benefits-header">
            <h2 className="section-title">
              <span>{/*locale-SectionTitle_wLOIic*/}</span>
            </h2>
            <p className="section-subtitle">
              <span>{/*locale-SectionSubtitle_YzS9hH*/}</span>
            </p>
          </div>
          <div className="features-benefits-grid">
            <div className="features-benefits-card">
              <div className="features-benefits-icon">
                <svg
                  width="32"
                  xmlns="http://www.w3.org/2000/svg"
                  height="32"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <h3 className="features-benefits-title">
                <span>{/*locale-FeaturesBenefitsTitle_ZXcVCT*/}</span>
              </h3>
              <p className="features-benefits-description">
                <span>{/*locale-FeaturesBenefitsDescription_UptLUZ*/}</span>
              </p>
            </div>
            <div className="features-benefits-card">
              <div className="features-benefits-icon">
                <svg
                  width="32"
                  xmlns="http://www.w3.org/2000/svg"
                  height="32"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M20 6L9 17l-5-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <h3 className="features-benefits-title">
                <span>{/*locale-FeaturesBenefitsTitle_qmF7HE*/}</span>
              </h3>
              <p className="features-benefits-description">
                <span>{/*locale-FeaturesBenefitsDescription_5peoog*/}</span>
              </p>
            </div>
            <div className="features-benefits-card">
              <div className="features-benefits-icon">
                <svg
                  width="32"
                  xmlns="http://www.w3.org/2000/svg"
                  height="32"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M2.062 12.348a1 1 0 0 1 0-.696a10.75 10.75 0 0 1 19.876 0a1 1 0 0 1 0 .696a10.75 10.75 0 0 1-19.876 0"></path>
                    <circle r="3" cx="12" cy="12"></circle>
                  </g>
                </svg>
              </div>
              <h3 className="features-benefits-title">
                <span>{/*locale-FeaturesBenefitsTitle_0GHtrJ*/}</span>
              </h3>
              <p className="features-benefits-description">
                <span>{/*locale-FeaturesBenefitsDescription_b9GT8Z*/}</span>
              </p>
            </div>
          </div>
        </div>
      </section>
      <section className="showcase-steps">
        <div className="showcase-steps-wrapper">
          <div className="showcase-steps-header">
            <h2 className="section-title">
              <span>{/*locale-SectionTitle_EOmrtI*/}</span>
            </h2>
            <p className="section-subtitle">
              <span>{/*locale-SectionSubtitle_ifKoo7*/}</span>
            </p>
          </div>
          <div className="showcase-steps-carousel">
            <div className="showcase-steps-track">
              <div className="active showcase-steps-slide">
                <div className="showcase-steps-visual">
                  <img
                    alt="Top view of a stylish home office desk with a laptop, planner, and coffee cup, showing hands on a blueprint."
                    src="https://images.pexels.com/photos/6894103/pexels-photo-6894103.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    className="showcase-steps-image"
                  />
                  <div className="showcase-steps-number">
                    <span>
                      <span>{/*locale-text_la5Nng*/}</span>
                    </span>
                  </div>
                </div>
                <div className="showcase-steps-content">
                  <h3 className="showcase-steps-title">
                    <span>{/*locale-ShowcaseStepsTitle_NYGsVo*/}</span>
                  </h3>
                  <p className="showcase-steps-description">
                    <span>{/*locale-ShowcaseStepsDescription_EaUR8J*/}</span>
                  </p>
                  <div className="showcase-steps-features">
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_A39eCu*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_Sid93G*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_32USF1*/}</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="showcase-steps-slide">
                <div className="showcase-steps-visual">
                  <img
                    alt="A woman writes in a notebook at a café table with a coffee and smartphone nearby."
                    src="https://images.pexels.com/photos/733856/pexels-photo-733856.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    className="showcase-steps-image"
                  />
                  <div className="showcase-steps-number">
                    <span>
                      <span>{/*locale-text_gjGuyA*/}</span>
                    </span>
                  </div>
                </div>
                <div className="showcase-steps-content">
                  <h3 className="showcase-steps-title">
                    <span>{/*locale-ShowcaseStepsTitle_NhugXx*/}</span>
                  </h3>
                  <p className="showcase-steps-description">
                    <span>{/*locale-ShowcaseStepsDescription_z8DtRE*/}</span>
                  </p>
                  <div className="showcase-steps-features">
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_rVBLRd*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_O89djW*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_ci0x7z*/}</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="showcase-steps-slide">
                <div className="showcase-steps-visual">
                  <img
                    alt="A minimalist office setup featuring a planner, clipboard, card, and pen, perfect for planning and organization."
                    src="https://images.pexels.com/photos/8062358/pexels-photo-8062358.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                    className="showcase-steps-image"
                  />
                  <div className="showcase-steps-number">
                    <span>
                      <span>{/*locale-text_Ra6EF2*/}</span>
                    </span>
                  </div>
                </div>
                <div className="showcase-steps-content">
                  <h3 className="showcase-steps-title">
                    <span>{/*locale-ShowcaseStepsTitle_jaOciY*/}</span>
                  </h3>
                  <p className="showcase-steps-description">
                    <span>{/*locale-ShowcaseStepsDescription_bh273l*/}</span>
                  </p>
                  <div className="showcase-steps-features">
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_8yjcoS*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_vHaBZD*/}</span>
                      </span>
                    </div>
                    <div className="showcase-steps-feature">
                      <svg
                        width="20"
                        xmlns="http://www.w3.org/2000/svg"
                        height="20"
                        viewBox="0 0 24 24"
                      >
                        <path
                          d="M20 6L9 17l-5-5"
                          fill="none"
                          stroke="currentColor"
                          strokeWidth="2"
                          strokeLinecap="round"
                          strokeLinejoin="round"
                        ></path>
                      </svg>
                      <span>
                        <span>{/*locale-text_uDGaPI*/}</span>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="showcase-steps-controls">
              <button
                aria-label="Previous step"
                className="showcase-steps-prev"
              >
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="m15 18l-6-6l6-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
              <div className="showcase-steps-indicators">
                <button
                  aria-label="Go to step 1"
                  className="showcase-steps-indicator active"
                ></button>
                <button
                  aria-label="Go to step 2"
                  className="showcase-steps-indicator"
                ></button>
                <button
                  aria-label="Go to step 3"
                  className="showcase-steps-indicator"
                ></button>
              </div>
              <button aria-label="Next step" className="showcase-steps-next">
                <svg
                  width="24"
                  xmlns="http://www.w3.org/2000/svg"
                  height="24"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="m9 18l6-6l-6-6"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="stats-indicators">
        <div className="stats-indicators-container">
          <div className="stats-indicators-header">
            <h2 className="section-title">
              <span>{/*locale-SectionTitle_1hPf88*/}</span>
            </h2>
            <p className="section-subtitle">
              <span>{/*locale-SectionSubtitle_Zda8uP*/}</span>
            </p>
          </div>
          <div className="stats-indicators-grid">
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"></path>
                    <circle
                      r=".5"
                      cx="7.5"
                      cy="7.5"
                      fill="currentColor"
                    ></circle>
                  </g>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_PJi8yA*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_w9rFtM*/}</span>
                </span>
              </div>
            </div>
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.12 2.12 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.12 2.12 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.12 2.12 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.12 2.12 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.12 2.12 0 0 0 1.597-1.16z"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_0R2A9i*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_3dEnCB*/}</span>
                </span>
              </div>
            </div>
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2M16 3.128a4 4 0 0 1 0 7.744M22 21v-2a4 4 0 0 0-3-3.87"></path>
                    <circle r="4" cx="9" cy="7"></circle>
                  </g>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_kvP3V1*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_tlNquH*/}</span>
                </span>
              </div>
            </div>
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M16 7h6v6"></path>
                    <path d="m22 7l-8.5 8.5l-5-5L2 17"></path>
                  </g>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_jxFS_P*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_dHnBop*/}</span>
                </span>
              </div>
            </div>
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="M12 6v6l4 2"></path>
                    <circle r="10" cx="12" cy="12"></circle>
                  </g>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_i11LJ5*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_YMkTQX*/}</span>
                </span>
              </div>
            </div>
            <div className="stats-indicators-card">
              <div className="stats-indicators-icon">
                <svg
                  width="28"
                  xmlns="http://www.w3.org/2000/svg"
                  height="28"
                  viewBox="0 0 24 24"
                >
                  <path
                    d="M20 6L9 17l-5-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
              </div>
              <div className="stats-indicators-content">
                <span className="stats-indicators-number">
                  <span>{/*locale-StatsIndicatorsNumber_jjcc0G*/}</span>
                </span>
                <span className="stats-indicators-label">
                  <span>{/*locale-StatsIndicatorsLabel_OjnJPf*/}</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="cta-submit">
        <div className="cta-submit-wrapper">
          <div className="cta-submit-card">
            <div className="cta-submit-content">
              <h2 className="section-title">
                <span>{/*locale-SectionTitle_EjjbTu*/}</span>
              </h2>
              <p className="section-subtitle">
                <span>{/*locale-SectionSubtitle_JYffLD*/}</span>
              </p>
              <div className="cta-submit-actions">
                <button className="btn-xl btn-primary cta-submit-button btn">
                  <svg
                    width="24"
                    xmlns="http://www.w3.org/2000/svg"
                    height="24"
                    viewBox="0 0 24 24"
                  >
                    <path
                      d="M12 3v12m5-7l-5-5l-5 5m14 7v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    ></path>
                  </svg>
                  <span>
                    <span>{/*locale-text_xZNahG*/}</span>
                  </span>
                </button>
                <button className="btn-xl btn btn-outline">
                  <span>{/*locale-Btn_FrIK-r*/}</span>
                </button>
              </div>
              <p className="cta-submit-note">
                <span>{/*locale-CtaSubmitNote_qCRq-a*/}</span>
              </p>
            </div>
            <div className="cta-submit-visual">
              <img
                alt="Stylish office workspace featuring dual monitors, a keyboard, notebooks, and decorative plant."
                src="https://images.pexels.com/photos/326501/pexels-photo-326501.jpeg?auto=compress&amp;cs=tinysrgb&amp;w=1500"
                className="cta-submit-image"
              />
            </div>
          </div>
        </div>
      </section>
      <div className="home-container4">
        <div className="home-container5">
          <Script
            html={`<style>
        @keyframes fadeSlideIn {from {opacity: 0;
transform: translateY(20px);}
to {opacity: 1;
transform: translateY(0);}}@keyframes fadeIn {from {opacity: 0;}
to {opacity: 1;}}
        </style> `}
          ></Script>
        </div>
      </div>
      <div className="home-container6">
        <div className="home-container7">
          <Script
            html={`<script defer data-name="homepage-interactions">
(function(){
  const heroCarousel = document.querySelector(".hero-carousel-slides")
  const heroSlides = heroCarousel.querySelectorAll(".hero-carousel-slide")
  const heroDots = document.querySelectorAll(".hero-carousel-dot")
  const heroPrev = document.querySelector(".hero-carousel-prev")
  const heroNext = document.querySelector(".hero-carousel-next")
  let heroCurrentSlide = 0
  const heroTotalSlides = heroSlides.length

  function showHeroSlide(index) {
    heroSlides.forEach((slide) => slide.classList.remove("active"))
    heroDots.forEach((dot) => dot.classList.remove("active"))

    heroSlides[index].classList.add("active")
    heroDots[index].classList.add("active")
  }

  function nextHeroSlide() {
    heroCurrentSlide = (heroCurrentSlide + 1) % heroTotalSlides
    showHeroSlide(heroCurrentSlide)
  }

  function prevHeroSlide() {
    heroCurrentSlide = (heroCurrentSlide - 1 + heroTotalSlides) % heroTotalSlides
    showHeroSlide(heroCurrentSlide)
  }

  heroNext.addEventListener("click", nextHeroSlide)
  heroPrev.addEventListener("click", prevHeroSlide)

  heroDots.forEach((dot, index) => {
    dot.addEventListener("click", () => {
      heroCurrentSlide = index
      showHeroSlide(heroCurrentSlide)
    })
  })

  const heroAutoplay = setInterval(nextHeroSlide, 5000)

  const showcaseTrack = document.querySelector(".showcase-steps-track")
  const showcaseSlides = showcaseTrack.querySelectorAll(".showcase-steps-slide")
  const showcaseIndicators = document.querySelectorAll(".showcase-steps-indicator")
  const showcasePrev = document.querySelector(".showcase-steps-prev")
  const showcaseNext = document.querySelector(".showcase-steps-next")
  let showcaseCurrentSlide = 0
  const showcaseTotalSlides = showcaseSlides.length

  function showShowcaseSlide(index) {
    showcaseSlides.forEach((slide) => slide.classList.remove("active"))
    showcaseIndicators.forEach((indicator) => indicator.classList.remove("active"))

    showcaseSlides[index].classList.add("active")
    showcaseIndicators[index].classList.add("active")
  }

  function nextShowcaseSlide() {
    showcaseCurrentSlide = (showcaseCurrentSlide + 1) % showcaseTotalSlides
    showShowcaseSlide(showcaseCurrentSlide)
  }

  function prevShowcaseSlide() {
    showcaseCurrentSlide = (showcaseCurrentSlide - 1 + showcaseTotalSlides) % showcaseTotalSlides
    showShowcaseSlide(showcaseCurrentSlide)
  }

  showcaseNext.addEventListener("click", nextShowcaseSlide)
  showcasePrev.addEventListener("click", prevShowcaseSlide)

  showcaseIndicators.forEach((indicator, index) => {
    indicator.addEventListener("click", () => {
      showcaseCurrentSlide = index
      showShowcaseSlide(showcaseCurrentSlide)
    })
  })

  const showcaseAutoplay = setInterval(nextShowcaseSlide, 6000)
})()
</script>`}
          ></Script>
        </div>
      </div>
      <Footer locale={props?.locale ?? ''}></Footer>
      <a href="https://play.teleporthq.io/signup">
        <div aria-label="Sign up to TeleportHQ" className="home-container8">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="home-icon90"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="home-text23">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Home
